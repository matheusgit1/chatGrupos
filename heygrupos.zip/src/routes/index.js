import React from 'react';

import AppRoutes from './app.routes';

function Routes(){
  return(
    <AppRoutes/>
  )
}

export default Routes;